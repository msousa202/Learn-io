import React from 'react';

    function Home() {
      return (
        <div>
          <h1>Welcome to the Python Course Platform!</h1>
          <p>Explore our roadmap to learn Python.</p>
        </div>
      );
    }

    export default Home;
